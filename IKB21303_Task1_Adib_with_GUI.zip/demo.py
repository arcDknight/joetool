"""
Quick demo - just click Run on this file in VS Code.

It will:
1. Hide sample_secret.txt inside sample_cover.png -> saves stego.png
2. Extract the hidden file back out -> saves it into extracted_output/
3. Print a comparison of file sizes

Change the file paths below to test your own cover image / secret file.
"""

import os
from stego_engine import hide_file, extract_file

COVER_IMAGE = "zombie_cover.jpg"
SECRET_FILE = "sample_secret.txt"       # try sample_secret_image.png too
OUTPUT_STEGO = "stego.png"
EXTRACT_DIR = "extracted_output"

if __name__ == "__main__":
    print("=== HIDING ===")
    hide_file(COVER_IMAGE, SECRET_FILE, OUTPUT_STEGO)

    print("\n=== EXTRACTING ===")
    extract_file(OUTPUT_STEGO, EXTRACT_DIR)

    print("\n=== FILE SIZE COMPARISON ===")
    cover_size = os.path.getsize(COVER_IMAGE)
    stego_size = os.path.getsize(OUTPUT_STEGO)
    print(f"Cover image size : {cover_size} bytes")
    print(f"Stego image size : {stego_size} bytes")
    print(f"Difference       : {stego_size - cover_size} bytes")

    print("\nDone. Take a screenshot of this terminal output for the report!")

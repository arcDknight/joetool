"""
IKB21303 - Assignment 2: Image Steganography Tool
GUI wrapper around stego_engine.py (LSB) and bpcs_engine.py (BPCS).

Run with:
    python gui_app.py

Requires: Pillow, numpy (for BPCS)
    pip install pillow numpy
"""

import os
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

from PIL import Image, ImageTk

import stego_engine
import bpcs_engine

PREVIEW_SIZE = (260, 260)


class StegoGUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("IKB21303 - Image Steganography Tool")
        self.geometry("880x640")
        self.minsize(820, 600)

        # ---- shared state ----
        self.mode = tk.StringVar(value="LSB")
        self.threshold = tk.DoubleVar(value=bpcs_engine.DEFAULT_THRESHOLD)

        self.hide_cover_path = tk.StringVar()
        self.hide_secret_path = tk.StringVar()
        self.hide_output_path = tk.StringVar(value="stego.png")

        self.extract_stego_path = tk.StringVar()
        self.extract_output_dir = tk.StringVar(value="extracted_output")

        self._cover_preview_img = None
        self._stego_preview_img = None

        self._build_layout()

    # ------------------------------------------------------------------
    # Layout
    # ------------------------------------------------------------------
    def _build_layout(self):
        # ---- top: mode selector shared across the whole app ----
        top = ttk.Frame(self, padding=10)
        top.pack(fill="x")

        ttk.Label(top, text="Mode:", font=("Segoe UI", 10, "bold")).pack(side="left")
        for label in ("LSB", "BPCS"):
            ttk.Radiobutton(
                top, text=label, value=label, variable=self.mode,
                command=self._on_mode_change
            ).pack(side="left", padx=(8, 0))

        self.threshold_frame = ttk.Frame(top)
        self.threshold_frame.pack(side="left", padx=(24, 0))
        ttk.Label(self.threshold_frame, text="BPCS complexity threshold:").pack(side="left")
        self.threshold_spin = ttk.Spinbox(
            self.threshold_frame, from_=0.05, to=0.45, increment=0.05,
            textvariable=self.threshold, width=6, format="%.2f"
        )
        self.threshold_spin.pack(side="left", padx=(6, 0))
        self._on_mode_change()  # set initial enabled/disabled state

        # ---- notebook: Hide tab / Extract tab ----
        notebook = ttk.Notebook(self)
        notebook.pack(fill="both", expand=True, padx=10, pady=(0, 10))

        hide_tab = ttk.Frame(notebook, padding=10)
        extract_tab = ttk.Frame(notebook, padding=10)
        notebook.add(hide_tab, text="Hide a secret file")
        notebook.add(extract_tab, text="Extract a secret file")

        self._build_hide_tab(hide_tab)
        self._build_extract_tab(extract_tab)

        # ---- bottom: log console ----
        log_frame = ttk.LabelFrame(self, text="Log", padding=6)
        log_frame.pack(fill="both", expand=False, padx=10, pady=(0, 10))
        self.log_text = tk.Text(log_frame, height=8, wrap="word", state="disabled")
        self.log_text.pack(fill="both", expand=True)

    def _on_mode_change(self):
        state = "normal" if self.mode.get() == "BPCS" else "disabled"
        self.threshold_spin.configure(state=state)

    # ------------------------------------------------------------------
    # Hide tab
    # ------------------------------------------------------------------
    def _build_hide_tab(self, parent):
        left = ttk.Frame(parent)
        left.pack(side="left", fill="both", expand=True)
        right = ttk.Frame(parent)
        right.pack(side="right", fill="y", padx=(20, 0))

        # Cover image
        ttk.Label(left, text="1. Cover image (picture to hide inside):").pack(anchor="w")
        row = ttk.Frame(left)
        row.pack(fill="x", pady=(2, 10))
        ttk.Entry(row, textvariable=self.hide_cover_path).pack(side="left", fill="x", expand=True)
        ttk.Button(row, text="Browse...", command=self._browse_cover).pack(side="left", padx=(6, 0))

        # Secret file
        ttk.Label(left, text="2. Secret file to hide (any type: .txt, .png, .pdf, ...):").pack(anchor="w")
        row = ttk.Frame(left)
        row.pack(fill="x", pady=(2, 10))
        ttk.Entry(row, textvariable=self.hide_secret_path).pack(side="left", fill="x", expand=True)
        ttk.Button(row, text="Browse...", command=self._browse_secret).pack(side="left", padx=(6, 0))

        # Output path
        ttk.Label(left, text="3. Output stego image (.png):").pack(anchor="w")
        row = ttk.Frame(left)
        row.pack(fill="x", pady=(2, 10))
        ttk.Entry(row, textvariable=self.hide_output_path).pack(side="left", fill="x", expand=True)
        ttk.Button(row, text="Save as...", command=self._browse_output).pack(side="left", padx=(6, 0))

        ttk.Button(left, text="Hide file  \u2192", command=self._do_hide).pack(anchor="w", pady=(10, 0))

        # Preview panel
        ttk.Label(right, text="Cover preview").pack()
        self.cover_preview_label = ttk.Label(right, relief="groove")
        self.cover_preview_label.pack(pady=(2, 12))

        ttk.Label(right, text="Result preview").pack()
        self.hide_result_label = ttk.Label(right, relief="groove")
        self.hide_result_label.pack(pady=(2, 0))

    def _browse_cover(self):
        path = filedialog.askopenfilename(
            title="Choose cover image",
            filetypes=[("Images", "*.png *.jpg *.jpeg *.bmp"), ("All files", "*.*")],
        )
        if path:
            self.hide_cover_path.set(path)
            self._show_preview(path, self.cover_preview_label, "cover")

    def _browse_secret(self):
        path = filedialog.askopenfilename(title="Choose secret file")
        if path:
            self.hide_secret_path.set(path)

    def _browse_output(self):
        path = filedialog.asksaveasfilename(
            title="Save stego image as", defaultextension=".png",
            filetypes=[("PNG image", "*.png")],
        )
        if path:
            self.hide_output_path.set(path)

    def _do_hide(self):
        cover = self.hide_cover_path.get().strip()
        secret = self.hide_secret_path.get().strip()
        output = self.hide_output_path.get().strip() or "stego.png"
        if not cover or not secret:
            messagebox.showerror("Missing info", "Please choose both a cover image and a secret file.")
            return

        mode = self.mode.get()
        threshold = self.threshold.get()

        def task():
            try:
                if mode == "LSB":
                    stego_engine.hide_file(cover, secret, output)
                else:
                    bpcs_engine.hide_file(cover, secret, output, threshold=threshold)
                self._log(f"[{mode}] Hidden '{secret}' inside '{cover}' -> '{output}'")
                self.after(0, lambda: self._show_preview(output, self.hide_result_label, "result"))
                self.after(0, lambda: messagebox.showinfo("Done", f"Secret file hidden successfully!\nSaved to: {output}"))
            except Exception as e:
                self._log(f"[{mode}] ERROR: {e}")
                self.after(0, lambda: messagebox.showerror("Hide failed", str(e)))

        threading.Thread(target=task, daemon=True).start()

    # ------------------------------------------------------------------
    # Extract tab
    # ------------------------------------------------------------------
    def _build_extract_tab(self, parent):
        left = ttk.Frame(parent)
        left.pack(side="left", fill="both", expand=True)
        right = ttk.Frame(parent)
        right.pack(side="right", fill="y", padx=(20, 0))

        ttk.Label(left, text="1. Stego image (contains a hidden file):").pack(anchor="w")
        row = ttk.Frame(left)
        row.pack(fill="x", pady=(2, 10))
        ttk.Entry(row, textvariable=self.extract_stego_path).pack(side="left", fill="x", expand=True)
        ttk.Button(row, text="Browse...", command=self._browse_stego).pack(side="left", padx=(6, 0))

        ttk.Label(left, text="2. Output folder for the recovered file:").pack(anchor="w")
        row = ttk.Frame(left)
        row.pack(fill="x", pady=(2, 10))
        ttk.Entry(row, textvariable=self.extract_output_dir).pack(side="left", fill="x", expand=True)
        ttk.Button(row, text="Choose...", command=self._browse_extract_dir).pack(side="left", padx=(6, 0))

        ttk.Button(left, text="Extract file  \u2192", command=self._do_extract).pack(anchor="w", pady=(10, 0))

        ttk.Label(right, text="Stego image preview").pack()
        self.stego_preview_label = ttk.Label(right, relief="groove")
        self.stego_preview_label.pack(pady=(2, 0))

    def _browse_stego(self):
        path = filedialog.askopenfilename(
            title="Choose stego image",
            filetypes=[("PNG image", "*.png"), ("All files", "*.*")],
        )
        if path:
            self.extract_stego_path.set(path)
            self._show_preview(path, self.stego_preview_label, "stego")

    def _browse_extract_dir(self):
        path = filedialog.askdirectory(title="Choose output folder")
        if path:
            self.extract_output_dir.set(path)

    def _do_extract(self):
        stego = self.extract_stego_path.get().strip()
        out_dir = self.extract_output_dir.get().strip() or "extracted_output"
        if not stego:
            messagebox.showerror("Missing info", "Please choose a stego image first.")
            return

        mode = self.mode.get()
        threshold = self.threshold.get()

        def task():
            try:
                if mode == "LSB":
                    result = stego_engine.extract_file(stego, out_dir)
                else:
                    result = bpcs_engine.extract_file(stego, out_dir, threshold=threshold)
                self._log(f"[{mode}] Extracted from '{stego}' -> '{result}'")
                self.after(0, lambda: messagebox.showinfo("Done", f"Secret file recovered!\nSaved to: {result}"))
            except Exception as e:
                self._log(f"[{mode}] ERROR: {e}")
                self.after(0, lambda: messagebox.showerror("Extract failed", str(e)))

        threading.Thread(target=task, daemon=True).start()

    # ------------------------------------------------------------------
    # Shared helpers
    # ------------------------------------------------------------------
    def _show_preview(self, image_path, label_widget, keep_ref_name):
        try:
            img = Image.open(image_path).convert("RGB")
            img.thumbnail(PREVIEW_SIZE)
            tk_img = ImageTk.PhotoImage(img)
            label_widget.configure(image=tk_img)
            setattr(self, f"_{keep_ref_name}_preview_img", tk_img)  # keep a reference!
        except Exception as e:
            self._log(f"Could not preview '{image_path}': {e}")

    def _log(self, message):
        def append():
            self.log_text.configure(state="normal")
            self.log_text.insert("end", message + "\n")
            self.log_text.see("end")
            self.log_text.configure(state="disabled")
        self.after(0, append)


if __name__ == "__main__":
    app = StegoGUI()
    app.mainloop()

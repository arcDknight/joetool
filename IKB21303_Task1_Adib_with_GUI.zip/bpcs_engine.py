"""
IKB21303 - Assignment 2: Image Steganography Tool
BPCS (Bit-Plane Complexity Segmentation) engine.

This is a from-scratch, simplified-but-faithful implementation of BPCS
(Kawaguchi & Eason). It shares the exact same payload format as
stego_engine.py (LSB engine):

    [1 byte filename length][filename][4 byte data length][data]

so the GUI can hide with one method and extract with either method as
long as the correct one is chosen (the two produce different stego
files - they are not interchangeable on the same image).

--------------------------------------------------------------------
How it works (short version)
--------------------------------------------------------------------
1. Each colour channel (R, G, B) of the cover image is split into its
   8 binary bit-planes (bit 0 = LSB ... bit 7 = MSB).
2. Each bit-plane is cut into 8x8 blocks.
3. For every block we compute its "complexity": the number of
   black/white border changes between adjacent bits, normalised by
   the maximum possible number of changes for an 8x8 block (112).
   A complexity close to 1.0 looks like noise/texture; a complexity
   close to 0.0 looks like a flat/simple area.
4. Blocks whose complexity is ABOVE a threshold (default 0.3) are
   "noise-like" - the human eye can't tell if we replace them, so we
   use them as containers ("vessels") for secret data.
5. We take 63 bits of secret payload for every vessel block found and
   write them into all 64 positions except position (0,0), which is
   reserved as a "conjugation flag".
6. If replacing the block with secret bits makes it too *simple*
   (complexity <= threshold), we XOR it with a black/white checkerboard
   pattern ("conjugation"). This flips its complexity to
   (1 - original complexity), which is always > threshold when
   threshold < 0.5, guaranteeing every block can be used. We then set
   the flag bit to 1 so extraction knows to undo the flip.
7. We keep consuming vessel blocks (skipping the top bit-plane, which
   is skipped to protect visual quality) until the whole payload has
   been written.

Extraction just repeats the same complexity test on the stego image
(deterministic - it only looks at the final pixel values, not the
original cover), pulls out the 63 data bits per vessel block (undoing
conjugation when the flag bit says to), and reassembles the payload.
"""

from PIL import Image
import numpy as np
import os

from stego_engine import _build_payload, _bytes_to_bits, _bits_to_bytes

BLOCK = 8
MAX_CHANGES = 2 * BLOCK * (BLOCK - 1)  # 112 for an 8x8 block
DEFAULT_THRESHOLD = 0.3
# Skip the top bit-plane(s) - embedding there is visible to the eye.
PLANES_USED = list(range(0, 7))  # bit-planes 0..6 (skip plane 7, the MSB)

_CHECKER = np.indices((BLOCK, BLOCK)).sum(axis=0) % 2  # 8x8 checkerboard of 0/1


# ---------------------------------------------------------------------
# Complexity helpers
# ---------------------------------------------------------------------

def _complexity(block: np.ndarray) -> float:
    """Border-change complexity of a binary 8x8 block, normalised 0..1."""
    changes = np.count_nonzero(block[:, 1:] != block[:, :-1])   # horizontal
    changes += np.count_nonzero(block[1:, :] != block[:-1, :])  # vertical
    return changes / MAX_CHANGES


def _conjugate(block: np.ndarray) -> np.ndarray:
    return block ^ _CHECKER


# ---------------------------------------------------------------------
# Bit-plane <-> array helpers
# ---------------------------------------------------------------------

def _channel_to_planes(channel: np.ndarray):
    """channel: HxW uint8 array -> list of 8 HxW binary (0/1) planes."""
    return [(channel >> p) & 1 for p in range(8)]


def _planes_to_channel(planes) -> np.ndarray:
    channel = np.zeros(planes[0].shape, dtype=np.uint8)
    for p, plane in enumerate(planes):
        channel |= (plane.astype(np.uint8) << p)
    return channel


def _iter_blocks(h_blocks: int, w_blocks: int):
    for by in range(h_blocks):
        for bx in range(w_blocks):
            yield by, bx


# ---------------------------------------------------------------------
# Capacity estimate (used by the GUI before hiding, and for error msgs)
# ---------------------------------------------------------------------

def estimate_capacity_bits(cover_path: str, threshold: float = DEFAULT_THRESHOLD) -> int:
    """Rough usable capacity in bits (63 data bits per qualifying block)."""
    img = Image.open(cover_path).convert("RGB")
    arr = np.array(img)
    h, w, _ = arr.shape
    h_blocks, w_blocks = h // BLOCK, w // BLOCK
    total_vessels = 0
    for c in range(3):
        planes = _channel_to_planes(arr[:, :, c])
        for p in PLANES_USED:
            plane = planes[p]
            for by, bx in _iter_blocks(h_blocks, w_blocks):
                block = plane[by * BLOCK:(by + 1) * BLOCK, bx * BLOCK:(bx + 1) * BLOCK]
                if _complexity(block) > threshold:
                    total_vessels += 1
    return total_vessels * (BLOCK * BLOCK - 1)  # 63 usable bits per block


# ---------------------------------------------------------------------
# Hide
# ---------------------------------------------------------------------

def hide_file(cover_path: str, secret_path: str, output_path: str = "stego_bpcs.png",
              threshold: float = DEFAULT_THRESHOLD) -> str:
    if not os.path.isfile(cover_path):
        raise FileNotFoundError(f"Cover image not found: {cover_path}")
    if not output_path.lower().endswith(".png"):
        raise ValueError("Output must be .png (PNG is lossless; JPG would destroy the hidden bits).")

    img = Image.open(cover_path).convert("RGB")
    arr = np.array(img)
    h, w, _ = arr.shape
    h_blocks, w_blocks = h // BLOCK, w // BLOCK
    if h_blocks == 0 or w_blocks == 0:
        raise ValueError("Cover image is too small for BPCS (must be at least 8x8 pixels).")
    # BPCS works on whole 8x8 blocks; crop any leftover edge pixels.
    crop_h, crop_w = h_blocks * BLOCK, w_blocks * BLOCK
    arr = arr[:crop_h, :crop_w, :].copy()

    payload_bits = _bytes_to_bits(_build_payload(secret_path))
    total_bits = len(payload_bits)
    idx = 0

    for c in range(3):
        if idx >= total_bits:
            break
        planes = _channel_to_planes(arr[:, :, c])
        for p in PLANES_USED:
            if idx >= total_bits:
                break
            plane = planes[p]
            for by, bx in _iter_blocks(h_blocks, w_blocks):
                if idx >= total_bits:
                    break
                y0, x0 = by * BLOCK, bx * BLOCK
                block = plane[y0:y0 + BLOCK, x0:x0 + BLOCK]
                if _complexity(block) <= threshold:
                    continue  # not a noise-like region, leave it alone

                chunk = payload_bits[idx: idx + (BLOCK * BLOCK - 1)]
                idx += len(chunk)
                if len(chunk) < BLOCK * BLOCK - 1:
                    chunk = chunk + [0] * (BLOCK * BLOCK - 1 - len(chunk))

                candidate = np.zeros((BLOCK, BLOCK), dtype=np.uint8)
                candidate.flat[1:] = chunk  # position (0,0) reserved for flag
                if _complexity(candidate) <= threshold:
                    candidate = _conjugate(candidate)
                    candidate[0, 0] = 1  # flag: this block was conjugated
                else:
                    candidate[0, 0] = 0

                plane[y0:y0 + BLOCK, x0:x0 + BLOCK] = candidate
            arr[:, :, c] = _planes_to_channel(planes)

    if idx < total_bits:
        raise ValueError(
            "Secret file too large for this cover image at this threshold. "
            "Try a bigger/noisier cover image or a lower complexity threshold."
        )

    out = np.array(img)
    out[:crop_h, :crop_w, :] = arr
    Image.fromarray(out, "RGB").save(output_path, "PNG")
    print(f"[bpcs hide_file] '{secret_path}' hidden inside '{cover_path}' -> '{output_path}'")
    return output_path


# ---------------------------------------------------------------------
# Extract
# ---------------------------------------------------------------------

def extract_file(stego_path: str, output_dir: str = ".",
                  threshold: float = DEFAULT_THRESHOLD) -> str:
    if not os.path.isfile(stego_path):
        raise FileNotFoundError(f"Stego image not found: {stego_path}")

    img = Image.open(stego_path).convert("RGB")
    arr = np.array(img)
    h, w, _ = arr.shape
    h_blocks, w_blocks = h // BLOCK, w // BLOCK

    bits = []
    fname_len = None
    data_len = None
    total_needed = None  # in bits, known only once header is decoded

    for c in range(3):
        if total_needed is not None and len(bits) >= total_needed:
            break
        planes = _channel_to_planes(arr[:, :, c])
        for p in PLANES_USED:
            if total_needed is not None and len(bits) >= total_needed:
                break
            plane = planes[p]
            for by, bx in _iter_blocks(h_blocks, w_blocks):
                if total_needed is not None and len(bits) >= total_needed:
                    break
                y0, x0 = by * BLOCK, bx * BLOCK
                block = plane[y0:y0 + BLOCK, x0:x0 + BLOCK]
                if _complexity(block) <= threshold:
                    continue

                flag = block[0, 0]
                data_block = _conjugate(block) if flag == 1 else block
                bits.extend(int(b) for b in data_block.flat[1:])

                # Try to decode the header as soon as we have enough bits.
                if total_needed is None and fname_len is None and len(bits) >= 8:
                    fname_len = _bits_to_bytes(bits[0:8])[0]
                if (total_needed is None and fname_len is not None
                        and len(bits) >= 8 + fname_len * 8 + 32):
                    header_end = 8 + fname_len * 8
                    data_len = int.from_bytes(
                        _bits_to_bytes(bits[header_end:header_end + 32]), byteorder="big")
                    total_needed = header_end + 32 + data_len * 8

    if total_needed is None or len(bits) < total_needed:
        raise ValueError(
            "Could not recover a valid payload from this image. "
            "Wrong mode selected (try LSB), wrong threshold, or the image has no hidden data."
        )

    fname_end = 8 + fname_len * 8
    filename = _bits_to_bytes(bits[8:fname_end]).decode("utf-8", errors="replace")
    len_end = fname_end + 32
    data_end = len_end + data_len * 8
    secret_data = _bits_to_bytes(bits[len_end:data_end])

    os.makedirs(output_dir, exist_ok=True)
    output_path = os.path.join(output_dir, filename)
    with open(output_path, "wb") as f:
        f.write(secret_data)

    print(f"[bpcs extract_file] hidden file recovered -> '{output_path}'")
    return output_path


if __name__ == "__main__":
    print("BPCS engine ready. Import hide_file() / extract_file() to use it.")
